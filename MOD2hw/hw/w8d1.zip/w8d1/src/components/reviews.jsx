function Reviews(props){
  return (
    <div className = "Reviews">
      <h3>Reviews</h3>
      <p>{ props.reviewAmount }</p>
    </div>
  )
}

export default Reviews