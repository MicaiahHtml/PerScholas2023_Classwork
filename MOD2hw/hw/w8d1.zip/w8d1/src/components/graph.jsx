function Graph(){
    return (
      <div className = "Graph">
        <h3>Graph</h3>
      </div>
    )
  }
  
  export default Graph