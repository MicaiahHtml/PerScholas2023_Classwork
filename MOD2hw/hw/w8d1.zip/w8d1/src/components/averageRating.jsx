function AverageRating(props){
  return (
    <div>
      <h3>Average Rating</h3>
      <p>{ props.rating }</p>
    </div>
  )
}

export default AverageRating