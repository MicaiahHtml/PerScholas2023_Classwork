function SentimentAnalysis(){
  return (
    <div className = "SentimentAnalysis">
      <h3>Sentiment Analysis</h3>
      <p>960</p>
      <p>122</p>
      <p>321</p>
    </div>
  )
}

export default SentimentAnalysis