function Sidebar(){
  return (
    <div className = "Sidebar">
      
      <ul>
        <li>Dashboard</li>
        <li>Widget</li>
        <li>Reviews</li>
        <li>Customers</li>
        <li>Online Analysis</li>
        <li>Settings</li>
      </ul>
    </div>
  )
}

export default Sidebar